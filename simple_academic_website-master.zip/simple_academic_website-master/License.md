My parts of this web site are licensed under
[CC BY](http://creativecommons.org/licenses/by/3.0/).
