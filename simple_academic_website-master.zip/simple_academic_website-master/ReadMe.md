This is the GitHub repository used to create a simple academic website. [The tutorial can be found here.](http://marisacarlos.com/pages/create-simple-academic-website)

This tutorial and website are heavily based on the tutorial and website from [Karl Broman](http://kbroman.org). Thanks Karl Broman!

---

My parts of this web site are licensed under
[CC BY](http://creativecommons.org/licenses/by/3.0/).

[![CC BY](http://i.creativecommons.org/l/by/3.0/88x31.png)](http://creativecommons.org/licenses/by/3.0/)
